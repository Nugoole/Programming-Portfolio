﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;

using Matrox.MatroxImagingLibrary;
using Matrox.MatroxImagingLibrary.WPF;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;

namespace TestWPF
{
    public class VMMilTest : ViewModelBase
    {
        private Image imageControl;
        private dynamic test;
        private MILWPFDisplay display;
        private MIL_ID displayID;

        public Image ImageControl
        {
            get => imageControl;
            set
            {
                imageControl = value;
                RaisePropertyChanged();
            }
        }

        public RelayCommand OnRun { get; set; }
        public RelayCommand OnTrain { get; set; }
        public RelayCommand OnFind { get; set; }
        public RelayCommand OnFindLine { get; set; }
        public MIL_ID DisplayID { get => displayID; set => Set(ref displayID, value); }

        public VMMilTest()
        {
            ImageControl = new Image();
            test = new milTest();
            OnRun = new RelayCommand(OnRunClicked);
            OnTrain = new RelayCommand(OnTrainClicked);
            OnFind = new RelayCommand(OnFindClicked);
            OnFindLine = new RelayCommand(OnFindLineClicked);
            DisplayID = test.DisplayId;
        }

        private void OnFindLineClicked()
        {
            test.FindEdge();
        }

        private void OnFindClicked()
        {
            test.Find();
        }

        private void OnTrainClicked()
        {
            test.Train();
        }

        private void OnRunClicked()
        {
            test.Grab();
        }
    }
}
